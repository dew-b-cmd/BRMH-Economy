# Kronos Economy Lab

아침 브리핑에서 경제 지표, 증시 리포트, NVDA 주가·전망을 볼 수 있습니다. 서버는 한국은행과 미 연준 자료의 제목·발행일·원문 링크를 15분 간격으로 확인합니다. 갱신에 실패하면 마지막으로 받은 목록을 이전 조회 자료로 표시합니다. 증권사 자료는 화면의 발행처 링크에서 읽을 수 있습니다.

로컬 서버의 **NVDA 주가·전망**은 Nasdaq의 정규장 마감 일봉을 가져옵니다. 화면을 열어 두면 15분마다 확인하며, 일봉이 바뀌면 Kronos-small이 최근 120개 일봉을 사용해 다음 5거래일의 예상 종가를 다시 계산합니다. 새로 마감된 종가가 Nasdaq에 반영되면 그 시점부터 전망을 계산합니다. 현재 거래일 계산에는 2026~2028년 미국 주식시장 일정이 포함됩니다. [Nasdaq NVDA 일봉](https://www.nasdaq.com/market-activity/stocks/nvda/historical) · [Nasdaq 거래 일정](https://www.nasdaqtrader.com/trader.aspx?id=calendar) · [NYSE 거래 일정](https://www.nyse.com/trade/hours-calendars)

## 아침 브리핑 연결

1. [관세청 품목별 수출입실적(GW)](https://www.data.go.kr/data/15101609/openapi.do)에서 활용 신청을 하고, [OpenDART](https://opendart.fss.or.kr/)에서 API 인증키를 발급받습니다.
2. `.env.example`을 같은 폴더에 `.env`로 복사합니다. 관세청 서비스키(일반 인증키 Decoding)와 OpenDART 키를 각각 해당 줄의 등호 오른쪽에 붙여넣고 저장합니다. 키는 로컬 서버에서만 읽습니다.
3. `run_briefing.cmd`를 실행하거나 이 폴더에서 `python briefing_server.py`를 실행하고 [로컬 아침 브리핑](http://127.0.0.1:8040/)을 엽니다. 브리핑 서버는 파이썬 표준 라이브러리로 실행합니다.

관세청은 전자집적회로(HS 8542)와 미용·기초화장용 제품류(HS 3304)의 최근 완료된 3개월에서 가장 최신으로 조회되는 월과 같은 품목의 전년 동월을 비교합니다. 달러로 표시하며, 전년 수치가 없거나 0이면 증감률은 비워 둡니다. OpenDART는 한국시간 기준 최근 7일의 접수 목록을 보여줍니다. 기본 조회는 코스피·코스닥이며, 개별 기업은 6자리 종목코드 대신 [8자리 OpenDART 고유번호](https://opendart.fss.or.kr/guide/detail.do?apiGrpCd=DS001&apiId=2019018)로 좁힐 수 있습니다. 페이지를 열 때 조회하며, 중복 호출을 줄이기 위해 수출은 최대 30분, 공시는 최대 5분 같은 조회 결과를 재사용합니다.

SEC EDGAR 공개 공시 API는 발급 키가 필요 없습니다. `.env`의 `SEC_CONTACT_EMAIL=` 오른쪽에 본인이 관리하는 연락용 이메일을 입력하고 서버를 다시 실행하세요. 이메일은 SEC 요청의 `User-Agent`에만 사용합니다. 미국 SEC 공시 카드에서 `AAPL`, `NVDA` 같은 티커 또는 SEC 고유번호(CIK)를 입력하면 최근 주요 공시 최대 8건과 원문 링크가 표시됩니다. [SEC 공개 API 안내](https://www.sec.gov/search-filings/edgar-application-programming-interfaces) · [SEC 접속 지침](https://www.sec.gov/search-filings/edgar-search-assistance/accessing-edgar-data)

## SEC 연간 실적과 Fastino 해설

SEC 카드에서 종목을 조회하고 **연간 실적 분석**을 누르면 최신 10-K에 신고된 매출과 순이익을 같은 공시의 전년 비교 수치와 함께 표시합니다. 표에는 회계연도 종료일, USD 단위, SEC XBRL 항목 및 원문 링크가 표시됩니다. 전년 값이 0 이하이거나 비교 수치가 없으면 증감률을 생략합니다. [SEC Company Facts API](https://www.sec.gov/search-filings/edgar-application-programming-interfaces)

Fastino 모델이 없어도 위 수치는 조회할 수 있습니다. 해설을 활성화하려면 별도 GPU 서버에서 해당 모델을 제공하는 vLLM 호환 서버를 실행합니다. 모델 카드의 BF16 체크포인트는 약 247GB이며, 제공자는 80GB급 GPU 4장 또는 B200 2장을 권장합니다. 카드가 안내하는 Nemotron 호환 버전과 실행 절차를 따르세요. [Fastino 모델 카드](https://huggingface.co/fastino/Fastino-Nemotron-3.5-Super-VL-Finance)

- `FINANCE_MODEL_BASE_URL`에는 모델 서버의 `/v1` 기본 주소를 넣습니다. 사설 터널을 사용하면 예를 들어 `http://127.0.0.1:8000/v1`입니다. 외부 주소에는 HTTPS를 사용합니다.
- 서버가 토큰을 요구하면 `FINANCE_MODEL_API_KEY`에 넣습니다. 모델 이름은 `fastino/Fastino-Nemotron-3.5-Super-VL-Finance`로 제공되어야 합니다.
- 브리핑을 다시 실행하고 분석 버튼을 누르면 공개 SEC 수치만 모델에 전달합니다. 숫자와 원문은 표에서 확인하고 AI 해설은 별도로 읽을 수 있습니다. [vLLM Chat Completions 안내](https://docs.vllm.ai/en/latest/serving/online_serving/openai_compatible_server/)

## MICU 강의에서 개인 리서치로

Windows에서 `run_micu_research.cmd`를 실행하면 MICU 강의실과 Kronos 개인 리서치 서버를 함께 엽니다. 실행 창을 열어 둔 채 [MICU 강의실](http://127.0.0.1:3000/?lesson=bottomup)에 기존 접속 암호로 로그인하세요. 이 실행 창에서 시작한 서버는 Ctrl+C로 종료합니다.

[개인 리서치](http://127.0.0.1:8040/research)에는 탑다운·바텀업 개념을 적용하는 **NVDA 실습**이 있습니다. 강의실 메뉴에서 실습으로 들어갈 수 있고, 리서치 화면의 교재 링크로 바텀업 장을 다시 열 수 있습니다.

1. SEC에서 최신 NVDA 10-K와 같은 보고서의 전년 비교 수치를 확인합니다.
2. 관세청 HS 8542 월간 수출과 연준 IPG3344S 계절조정 생산지수를 각자의 기준월로 읽습니다. [관세청](https://www.data.go.kr/data/15101609/openapi.do) · [FRED](https://fred.stlouisfed.org/series/IPG3344S)
3. French Data Library의 전자장비 업종 포트폴리오(Chips)와 미국 시장(Mkt-RF + RF)의 수익률을 공통 월로 맞춰 비교합니다. 3개월·6개월 수익률은 월별 수익률을 복리로 연결합니다. [French Data Library](https://mba.tuck.dartmouth.edu/pages/faculty/Ken.French/data_library.html)
새 PC에서 NVDA 전망용 CPU 환경을 만들 때는 Python 3.12를 사용합니다. 브리핑은 같은 폴더의 .venv를 자동으로 찾습니다.

~~~powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install torch==2.7.1 --index-url https://download.pytorch.org/whl/cpu
.\.venv\Scripts\python.exe -m pip install "numpy<3" "pandas>=2.2,<3" einops==0.8.1 huggingface_hub==0.33.1 tqdm==4.67.1 safetensors==0.6.2
.\.venv\Scripts\python.exe prepare_research_model.py
~~~

## 명령줄에서 다른 종목과 봉 주기 실험

Python 3.12 환경에서 프로젝트 폴더를 열고 아래 명령을 실행합니다.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe forecast.py .\candles.csv --symbol "종목명 / 통화" --cadence "일봉" --download
```

CSV 필수 열은 `timestamps,open,high,low,close,volume`입니다. `amount`는 선택입니다. 시간 오름차순으로 정렬된 단일 종목·동일 봉 주기의 파일을 사용하세요. 마지막 30개 봉의 시각은 모델에 전달하고, 가격은 예측 후 채점에 사용합니다. 기본 입력 256개와 평가 30개를 합쳐 최소 286개 봉이 필요합니다. 예측과 실제 종가는 `kronos-result.json`에 저장됩니다.

가중치를 이미 캐시했다면 이후 실행에서 `--download`를 빼고 사용할 수 있습니다. 같은 파일에 덮어쓰지 않도록 다음 실험에는 `--out kronos-result-2.json`처럼 다른 이름을 지정합니다.

## 출처와 현재 범위

- `model/`, `requirements.txt`, `LICENSE`는 제공된 Kronos ZIP에서 가져왔습니다. [Kronos 원 프로젝트](https://github.com/shiyu-coder/Kronos)
- 원본 ZIP의 `webui/prediction_results/`에는 BTC/USDT 선물 24개와 BCH/USDT 선물 5개의 5분봉 실험 결과 JSON이 있습니다. `finetune_csv/data/HK_ali_09988_kline_5min_all.csv`는 홍콩 알리바바(09988)의 5분봉 원본 CSV입니다. 원본 WebUI 결과 JSON과 이 앱에서 저장한 결과 JSON의 형식은 다릅니다.
- 리서치 예시는 과거 공식 발표입니다. 아침 브리핑과 별도 영역에 표시합니다.
