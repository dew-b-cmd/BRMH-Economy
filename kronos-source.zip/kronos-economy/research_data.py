"""Inputs and comparisons for the NVDA guided research case."""

import csv
from datetime import date
from io import BytesIO, StringIO
from math import isfinite, prod
import re
from zipfile import ZipFile


FRED_URL = "https://fred.stlouisfed.org/series/IPG3344S"
FRED_CSV = "https://fred.stlouisfed.org/graph/fredgraph.csv?id=IPG3344S"
FRENCH_LIBRARY = "https://mba.tuck.dartmouth.edu/pages/faculty/Ken.French/data_library.html"
FRENCH_FTP = "https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/"
SECTOR_ZIP = FRENCH_FTP + "49_Industry_Portfolios_CSV.zip"
MARKET_ZIP = FRENCH_FTP + "F-F_Research_Data_Factors_CSV.zip"
NVDA_REVISION = "d12e096810bbd52aa4c762ccf088f9c2bed31ae8"
NVDA_DATASET = "https://huggingface.co/datasets/misterdonn/finance-datasets"
NVDA_SOURCE = f"{NVDA_DATASET}/blob/{NVDA_REVISION}/stocks/NVDA.csv"
NVDA_CSV = f"{NVDA_DATASET}/raw/{NVDA_REVISION}/stocks/NVDA.csv"
PRICE_FIELDS = ("timestamps", "open", "high", "low", "close", "volume")
LOOKBACK = 120
HORIZON = 5


def production(raw, today):
    rows = csv.DictReader(StringIO(raw.decode("utf-8-sig")))
    monthly = {}
    for row in rows:
        observed = date.fromisoformat(row["observation_date"])
        value = row["IPG3344S"]
        if observed < today.replace(day=1) and value not in ("", "."):
            index = float(value)
            if isfinite(index) and index > 0:
                monthly[observed.isoformat()[:7]] = index
    latest = max(monthly)
    prior = monthly.get(f"{int(latest[:4]) - 1:04d}{latest[4:]}")
    return {
        "month": latest, "value": monthly[latest], "source": FRED_URL,
        "yoy_percent": round((monthly[latest] / prior - 1) * 100, 2) if prior else None,
    }


def monthly_returns(raw, names):
    """Read the first monthly block. The industry file lists value weights first."""
    with ZipFile(BytesIO(raw)) as archive:
        member, = archive.infolist()
        if member.file_size > 4 * 1024 * 1024:
            raise ValueError("Unexpected research CSV size.")
        reader = csv.reader(StringIO(archive.read(member).decode("utf-8-sig", errors="replace")))
        for row in reader:
            header = [value.strip() for value in row]
            if header and header[0] == "" and all(name in header for name in names):
                break
        else:
            raise ValueError("Monthly research header not found.")

        indices = [header.index(name) for name in names]
        result = {}
        for row in reader:
            month = row[0].strip() if row else ""
            if not re.fullmatch(r"[0-9]{4}(0[1-9]|1[0-2])", month):
                break
            numbers = [float(row[index]) for index in indices]
            if all(isfinite(value) and value not in (-99.99, -999) for value in numbers):
                result[month] = sum(numbers)
        return result


def sector_comparison(industry_zip, market_zip, today):
    sector = monthly_returns(industry_zip, ("Chips",))
    market = monthly_returns(market_zip, ("Mkt-RF", "RF"))
    common = set(sector) & set(market)
    latest = max(month for month in common if month < today.strftime("%Y%m"))
    last_index = int(latest[:4]) * 12 + int(latest[4:]) - 1
    periods = []
    for months in (1, 3, 6):
        window = [f"{index // 12:04d}{index % 12 + 1:02d}"
                  for index in range(last_index - months + 1, last_index + 1)]
        if not all(month in common for month in window):
            continue
        industry_return = (prod(1 + sector[month] / 100 for month in window) - 1) * 100
        market_return = (prod(1 + market[month] / 100 for month in window) - 1) * 100
        periods.append({
            "months": months, "start": window[0], "end": latest,
            "industry": round(industry_return, 2), "market": round(market_return, 2),
            "difference_pp": round(industry_return - market_return, 2),
        })
    return {"periods": periods, "source": FRENCH_LIBRARY}


def normalize_price_csv(raw, today):
    reader = csv.DictReader(StringIO(raw.decode("utf-8-sig")))
    header = {name.strip().lower(): name for name in (reader.fieldnames or ())}
    date_key = next((header[key] for key in ("timestamps", "date") if key in header), None)
    if not date_key or not all(name in header for name in PRICE_FIELDS[1:]):
        raise ValueError("CSV에 날짜, open, high, low, close, volume 열이 필요합니다.")
    prices = {}
    for row in reader:
        symbol = row.get(header.get("symbol", "")) or ""
        if symbol and symbol.strip().upper() != "NVDA":
            raise ValueError("이 실험에는 NVDA 일봉 CSV를 사용하세요.")
        try:
            day = date.fromisoformat((row[date_key] or "").strip()[:10])
        except ValueError:
            raise ValueError("CSV 날짜는 YYYY-MM-DD 형식으로 입력하세요.") from None
        if day >= today:
            continue
        if day.weekday() >= 5 or day in prices:
            raise ValueError("거래일이 중복되었거나 주말 데이터가 있습니다. NVDA 일봉을 사용하세요.")
        try:
            opening, high, low, close, volume = [float(row[header[name]]) for name in PRICE_FIELDS[1:]]
        except (TypeError, ValueError):
            raise ValueError("CSV의 가격과 거래량을 숫자로 읽을 수 없습니다.") from None
        if (not all(isfinite(number) for number in (opening, high, low, close, volume))
                or not 0 < low <= min(opening, close) <= max(opening, close) <= high or volume < 0):
            raise ValueError("CSV의 가격 범위 또는 거래량이 올바르지 않습니다.")
        prices[day] = (opening, high, low, close, volume)
    days = sorted(prices)[-(LOOKBACK + HORIZON):]
    if len(days) < LOOKBACK + HORIZON:
        raise ValueError(f"완료된 NVDA 일봉이 최소 {LOOKBACK + HORIZON}개 필요합니다.")
    normalized = StringIO(newline="")
    writer = csv.writer(normalized)
    writer.writerow(PRICE_FIELDS)
    writer.writerows((day.isoformat(), *prices[day]) for day in days)
    return normalized.getvalue(), days[LOOKBACK - 1].isoformat(), days[-1].isoformat()
