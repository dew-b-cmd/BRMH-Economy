@echo off
setlocal
cd /d "%~dp0"
set "KRONOS_PYTHON=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%KRONOS_PYTHON%" (
    "%KRONOS_PYTHON%" briefing_server.py
) else (
    where py >nul 2>nul
    if errorlevel 1 (
        python briefing_server.py
    ) else (
        py -3 briefing_server.py
    )
)
if errorlevel 1 pause
