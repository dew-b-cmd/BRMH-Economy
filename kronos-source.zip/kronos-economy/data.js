window.workspaceData = {
  "replay": {
    "label": "NVDA (USD)",
    "cadence": "일봉",
    "provenance": "NVDA 과거 일봉 예제 · Kronos-small 실행",
    "source": "NeoQuasar/Kronos-small · 평가 모드 · 표본 1개 · seed 42 · 마지막 구간 홀드아웃",
    "last_close": 192.8500061035156,
    "lookback": 120,
    "rows": [
      {
        "time": "2026-02-25T00:00:00",
        "forecast": 190.4652099609375,
        "actual": 195.55999755859372
      },
      {
        "time": "2026-02-26T00:00:00",
        "forecast": 190.2757568359375,
        "actual": 184.88999938964844
      },
      {
        "time": "2026-02-27T00:00:00",
        "forecast": 179.41116333007812,
        "actual": 177.19000244140625
      },
      {
        "time": "2026-03-02T00:00:00",
        "forecast": 198.60218811035156,
        "actual": 182.47999572753903
      },
      {
        "time": "2026-03-03T00:00:00",
        "forecast": 203.00070190429688,
        "actual": 180.0500030517578
      }
    ],
    "price_source": "https://huggingface.co/datasets/misterdonn/finance-datasets/blob/d12e096810bbd52aa4c762ccf088f9c2bed31ae8/stocks/NVDA.csv"
  },
  "sources": [
    {
      "id": "ECON-GUIDE-DART",
      "title": "금융감독원 OpenDART",
      "text": "기업 분기·반기·사업보고서, 공시 원문, 재무계정을 조회할 출처다. 분기 매출액과 영업이익을 비교할 때 보고 기간, 연결 여부, 당기 3개월과 누적 기준을 확인한다.",
      "url": "https://opendart.fss.or.kr/intro/main.do"
    },
    {
      "id": "ECON-GUIDE-CUSTOMS",
      "title": "관세청 품목별 수출입실적",
      "text": "수출입 통관 실적을 월과 품목 HS 코드 기준으로 확인할 출처다. 품목 범위를 먼저 정의한 뒤 동일 HS 코드의 전년 동월 및 최근 몇 달을 비교한다. 정정된 값과 잠정치를 구분한다.",
      "url": "https://www.data.go.kr/data/15101609/openapi.do"
    },
    {
      "id": "ECON-GUIDE-ECOS",
      "title": "한국은행 ECOS",
      "text": "기준금리, 원·달러 환율 등 국내 경제 시계열을 확인할 출처다. 지표 단위와 관측 주기를 확인하고 금리는 퍼센트포인트 변화와 전년 대비 성장률을 구분한다.",
      "url": "https://ecos.bok.or.kr/api/"
    },
    {
      "id": "ECON-GUIDE-KOSIS",
      "title": "KOSIS 국가통계포털",
      "text": "산업생산, 소매판매, 소비자물가 등 국내 통계표를 확인할 출처다. 산업 분류와 기준연도, 원계열과 계절조정 여부를 확인한다.",
      "url": "https://kosis.kr/openapi/introduce/introduce_01List.do"
    },
    {
      "id": "ECON-GUIDE-KDI",
      "title": "KDI 월간 경제동향",
      "text": "국내 경기, 생산, 소비, 투자, 수출입의 흐름을 함께 읽을 수 있는 월간 경제동향 자료다. 발간일과 실제 통계의 관측 기간을 구분한다.",
      "url": "https://www.kdi.re.kr/research/monTrends"
    },
    {
      "id": "ECON-GUIDE-KRX",
      "title": "한국거래소 KRX Open API",
      "text": "코스피·코스닥의 주식 일별매매정보와 지수 자료를 확인할 출처다. 거래일과 데이터 종류를 표시한다.",
      "url": "https://openapi.krx.co.kr/contents/OPP/INFO/service/OPPINFO004.cmd"
    },
    {
      "id": "ECON-GUIDE-FRED",
      "title": "세인트루이스 연은 FRED",
      "text": "미국 금리, 물가, 고용 등 거시경제 시계열을 확인할 출처다. 지표별 관측일, 공표 주기, 단위와 개정 이력을 확인한다.",
      "url": "https://fred.stlouisfed.org/docs/api/fred/"
    },
    {
      "id": "ECON-GUIDE-SEC",
      "title": "미국 SEC EDGAR",
      "text": "미국 상장사의 10-K, 10-Q 제출 이력과 XBRL 재무 수치를 확인할 출처다. 회사 회계연도와 통화, 기간 및 연결 범위를 맞춰 비교한다.",
      "url": "https://www.sec.gov/search-filings/edgar-application-programming-interfaces"
    },
    {
      "id": "ECON-DATA-KBEAUTY-2025",
      "title": "식약처 · 2025년 화장품 수출 실적",
      "text": "식품의약품안전처가 2026년 5월 22일 발표한 한국 화장품 2025년 연간 수출액은 114억 달러이며, 전년 대비 11.8% 증가했다. 개별 기업의 수출이나 매출은 해당 기업 공시에서 별도로 확인한다.",
      "url": "https://www.mfds.go.kr/brd/m_1256/view.do?itm_seq_1=0&itm_seq_2=0&multi_itm_seq=0&page=1&seq=23",
      "period": "2025년 연간"
    },
    {
      "id": "ECON-DATA-CHIPS-2025H1",
      "title": "산업통상부 · 2025년 상반기 반도체 수출",
      "text": "산업통상부의 2025년 상반기 수출입 동향에서 한국 반도체 수출은 733억 달러로 전년 동기 대비 11.4% 증가했다. 2025년 상반기 누계 기준이다.",
      "url": "https://www.motir.go.kr/kor/article/ATCL3f49a5a8c/170672/view",
      "period": "2025년 상반기"
    }
  ]
};
window.marketReports = {"checked": "2026-11-22T16:27:00+00:00", "feeds": [{"label": "\ud55c\uad6d\uc740\ud589 \u00b7 \uc77c\uc77c \uae08\uc735\uc678\ud658\uc2dc\uc7a5", "home": "https://www.bok.or.kr/portal/bbs/B0000348/list.do?menuNo=201109", "items": [{"title": "\uc77c\uc77c \uae08\uc735\uc678\ud658\uc2dc\uc7a5 \ub3d9\ud5a5(11.20\uc77c)", "url": "https://www.bok.or.kr/portal/bbs/B0000348/view.do?nttId=11066881&menuNo=201109", "published": "2026-11-20T17:52:00+09:00"}, {"title": "\uc77c\uc77c \uae08\uc735\uc678\ud658\uc2dc\uc7a5 \ub3d9\ud5a5(11.19\uc77c)", "url": "https://www.bok.or.kr/portal/bbs/B0000348/view.do?nttId=11066835&menuNo=201109", "published": "2026-11-19T18:16:47+09:00"}, {"title": "\uc77c\uc77c \uae08\uc735\uc678\ud658\uc2dc\uc7a5 \ub3d9\ud5a5(11.18\uc77c)", "url": "https://www.bok.or.kr/portal/bbs/B0000348/view.do?nttId=11066794&menuNo=201109", "published": "2026-11-18T18:18:00+09:00"}, {"title": "\uc77c\uc77c \uae08\uc735\uc678\ud658\uc2dc\uc7a5 \ub3d9\ud5a5(11.17\uc77c)", "url": "https://www.bok.or.kr/portal/bbs/B0000348/view.do?nttId=11066739&menuNo=201109", "published": "2026-11-17T18:19:28+09:00"}, {"title": "\uc77c\uc77c \uae08\uc735\uc678\ud658\uc2dc\uc7a5 \ub3d9\ud5a5(11.16\uc77c)", "url": "https://www.bok.or.kr/portal/bbs/B0000348/view.do?nttId=11066669&menuNo=201109", "published": "2026-11-16T18:07:15+09:00"}], "updated": "2026-11-22T16:27:00+00:00", "status": "ok"}, {"label": "\ud55c\uad6d\uc740\ud589 \u00b7 \uc8fc\ub825\uc0b0\uc5c5", "home": "https://www.bok.or.kr/portal/bbs/B0000357/list.do?menuNo=201127", "items": [{"title": "2024\ub144 4/4\ubd84\uae30 \uc8fc\ub825\uc0b0\uc5c5 \ubaa8\ub2c8\ud130\ub9c1 \ubcf4\uace0\uc11c", "url": "https://www.bok.or.kr/portal/bbs/B0000357/view.do?nttId=10089810&menuNo=201127", "published": "2025-02-17T16:00:00+09:00"}, {"title": "2024\ub144 3/4\ubd84\uae30 \uc8fc\ub825\uc0b0\uc5c5 \ubaa8\ub2c8\ud130\ub9c1 \ubcf4\uace0\uc11c", "url": "https://www.bok.or.kr/portal/bbs/B0000357/view.do?nttId=10088074&menuNo=201127", "published": "2024-11-18T16:00:00+09:00"}, {"title": "2024\ub144 2/4\ubd84\uae30 \uc8fc\ub825\uc0b0\uc5c5 \ubaa8\ub2c8\ud130\ub9c1 \ubcf4\uace0\uc11c", "url": "https://www.bok.or.kr/portal/bbs/B0000357/view.do?nttId=10086376&menuNo=201127", "published": "2024-08-09T16:00:00+09:00"}, {"title": "2024\ub144 1/4\ubd84\uae30 \uc8fc\ub825\uc0b0\uc5c5 \ubaa8\ub2c8\ud130\ub9c1 \ubcf4\uace0\uc11c", "url": "https://www.bok.or.kr/portal/bbs/B0000357/view.do?nttId=10084125&menuNo=201127", "published": "2024-05-14T18:18:51+09:00"}, {"title": "2023\ub144 4/4\ubd84\uae30 \uc8fc\ub825\uc0b0\uc5c5 \ubaa8\ub2c8\ud130\ub9c1 \ubcf4\uace0\uc11c", "url": "https://www.bok.or.kr/portal/bbs/B0000357/view.do?nttId=10082403&menuNo=201127", "published": "2024-02-13T14:02:35+09:00"}], "updated": "2026-11-22T16:27:00+00:00", "status": "ok"}, {"label": "\ubbf8 \uc5f0\uc900 \u00b7 \ud1b5\ud654\uc815\ucc45", "home": "https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm", "items": [{"title": "Minutes of the Federal Open Market Committee, October 27-28, 2026", "url": "https://www.federalreserve.gov/newsevents/pressreleases/monetary20261118a.htm", "published": "2026-11-18T19:00:00+00:00"}, {"title": "Federal Reserve announces revised tentative schedule of Federal Open Market Committee meetings in 2027", "url": "https://www.federalreserve.gov/newsevents/pressreleases/monetary20261112a.htm", "published": "2026-11-12T17:45:00+00:00"}, {"title": "Federal Reserve issues FOMC statement", "url": "https://www.federalreserve.gov/newsevents/pressreleases/monetary20261028a.htm", "published": "2026-10-28T18:00:00+00:00"}, {"title": "Minutes of the Board's discount rate meetings on August 17, September 9, and September 16, 2026", "url": "https://www.federalreserve.gov/newsevents/pressreleases/monetary20261013a.htm", "published": "2026-10-13T18:00:00+00:00"}, {"title": "Minutes of the Federal Open Market Committee, September 15-16, 2026", "url": "https://www.federalreserve.gov/newsevents/pressreleases/monetary20261007a.htm", "published": "2026-10-07T18:00:00+00:00"}], "updated": "2026-11-22T16:27:00+00:00", "status": "ok"}]};
