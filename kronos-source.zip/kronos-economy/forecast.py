"""Run a local Kronos holdout experiment or forecast future bars."""

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


FEATURES = ["open", "high", "low", "close", "volume", "amount"]


def load_prices(path, count):
    frame = pd.read_csv(path)
    required = {"timestamps", *FEATURES[:-1]}
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError("CSV 필수 열 누락: " + ", ".join(sorted(missing)))
    if len(frame) < count:
        raise ValueError(f"CSV에는 최소 {count}개 봉이 필요합니다.")
    frame = frame.tail(count).reset_index(drop=True).copy()
    frame["timestamps"] = pd.to_datetime(frame["timestamps"], errors="raise")
    times = frame["timestamps"]
    if times.isna().any() or times.duplicated().any() or not times.is_monotonic_increasing:
        raise ValueError("timestamps는 중복 없이 시간 오름차순이어야 합니다.")
    columns = [column for column in FEATURES if column in frame]
    frame[columns] = frame[columns].apply(pd.to_numeric, errors="raise")
    values = frame[columns].to_numpy()
    if not np.isfinite(values).all() or (values[:, :4] <= 0).any() or (values[:, 4:] < 0).any():
        raise ValueError("가격은 양수, 거래량과 거래대금은 0 이상의 유한한 수여야 합니다.")
    return frame


def load_holdout(path, lookback, horizon):
    frame = load_prices(path, lookback + horizon)
    return frame.iloc[:lookback], frame.iloc[lookback:]


def predict_closes(predictor, history, timestamps, sample_count):
    columns = [column for column in FEATURES if column in history]
    output = predictor.predict(
        df=history[columns].copy(),
        x_timestamp=history["timestamps"].reset_index(drop=True),
        y_timestamp=timestamps,
        pred_len=len(timestamps),
        T=1.0, top_p=0.9, sample_count=sample_count, verbose=False,
    )
    estimates = output["close"].to_numpy()
    if len(estimates) != len(timestamps) or not np.isfinite(estimates).all() or (estimates <= 0).any():
        raise ValueError("Kronos가 유효한 종가 예측을 반환하지 않았습니다.")
    return estimates


def run_experiment(predictor, history, holdout, label, cadence, sample_count):
    timestamps = holdout["timestamps"].reset_index(drop=True)
    estimates = predict_closes(predictor, history, timestamps, sample_count)
    return {
        "label": label, "cadence": cadence,
        "provenance": "로컬 Kronos-small 실행",
        "source": f"NeoQuasar/Kronos-small · 표본 {sample_count}개 · seed 42 · 마지막 구간 홀드아웃",
        "last_close": float(history["close"].iloc[-1]), "lookback": len(history),
        "rows": [
            {"time": time.isoformat(), "forecast": float(estimate), "actual": float(actual)}
            for time, estimate, actual in zip(timestamps, estimates, holdout["close"])
        ],
    }


def run_future(predictor, history, dates, sample_count):
    timestamps = pd.Series(pd.to_datetime(dates, format="%Y-%m-%d", errors="raise"))
    if (not 1 <= len(timestamps) <= 120 or timestamps.isna().any() or timestamps.duplicated().any()
            or not timestamps.is_monotonic_increasing or timestamps.iloc[0] <= history["timestamps"].iloc[-1]):
        raise ValueError("예측 날짜는 마지막 입력일보다 뒤여야 하며 중복 없이 오름차순이어야 합니다.")
    estimates = predict_closes(predictor, history, timestamps, sample_count)
    return {"rows": [{"time": day, "forecast": float(estimate)} for day, estimate in zip(dates, estimates)]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", type=Path)
    parser.add_argument("--symbol", required=True, help="종목과 가격 통화를 표시하는 이름")
    parser.add_argument("--cadence", required=True, help="예: 일봉 또는 5분봉")
    parser.add_argument("--lookback", type=int, choices=range(32, 513), default=256, metavar="32-512")
    parser.add_argument("--horizon", type=int, choices=range(2, 121), default=30, metavar="2-120")
    parser.add_argument("--future-dates", nargs="+", metavar="YYYY-MM-DD", help="미래 종가를 예측할 거래일")
    parser.add_argument("--samples", type=int, choices=range(1, 6), default=1, metavar="1-5")
    parser.add_argument("--download", action="store_true", help="로컬 캐시에 없으면 Hugging Face에서 가중치 다운로드")
    parser.add_argument("--model-root", type=Path, help="준비된 tokenizer와 predictor 폴더")
    parser.add_argument("--out", type=Path, default=Path("kronos-result.json"))
    args = parser.parse_args()
    try:
        if not all(0 < len(value.strip()) <= 180 for value in (args.symbol, args.cadence)):
            raise ValueError("종목과 봉 주기는 1~180자로 입력하세요.")
        if args.future_dates:
            history = load_prices(args.csv, args.lookback)
        else:
            history, holdout = load_holdout(args.csv, args.lookback, args.horizon)
        import torch
        from model import Kronos, KronosPredictor, KronosTokenizer

        torch.manual_seed(42)
        if args.model_root:
            tokenizer_source = args.model_root / "tokenizer"
            model_source = args.model_root / "predictor"
            for source in (tokenizer_source, model_source):
                if not all((source / name).is_file() for name in ("config.json", "model.safetensors")):
                    raise ValueError("prepare_research_model.py를 먼저 실행하세요.")
        else:
            tokenizer_source = "NeoQuasar/Kronos-Tokenizer-base"
            model_source = "NeoQuasar/Kronos-small"
        options = {"local_files_only": bool(args.model_root) or not args.download}
        tokenizer = KronosTokenizer.from_pretrained(str(tokenizer_source), **options)
        model = Kronos.from_pretrained(str(model_source), **options)
        tokenizer.eval()
        model.eval()
        predictor = KronosPredictor(model, tokenizer, device="cpu", max_context=512)
        if args.future_dates:
            result = run_future(predictor, history, args.future_dates, args.samples)
        else:
            result = run_experiment(predictor, history, holdout, args.symbol.strip(), args.cadence.strip(), args.samples)
        with args.out.open("x", encoding="utf-8") as file:
            json.dump(result, file, ensure_ascii=False, allow_nan=False, indent=2)
    except ImportError as error:
        parser.exit(1, f"모델 의존성이 필요합니다. README의 설치 절차를 확인하세요. ({error})\n")
    except (ValueError, OSError, RuntimeError) as error:
        parser.exit(1, f"실험을 완료하지 못했습니다: {error}\n")
    print(args.out.resolve())


if __name__ == "__main__":
    main()
