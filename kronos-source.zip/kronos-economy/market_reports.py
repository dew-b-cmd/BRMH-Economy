"""Refresh public report titles, publication dates and links for the dashboard."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import json
import os
from pathlib import Path
from tempfile import NamedTemporaryFile
from threading import Event
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener
from xml.etree import ElementTree


DATA = Path(__file__).with_name("data.js")
MARKER = "\nwindow.marketReports = "
REFRESH_SECONDS = 15 * 60
MAX_FEED_BYTES = 1024 * 1024
FEEDS = (
    ("한국은행 · 일일 금융외환시장", "https://www.bok.or.kr/portal/bbs/B0000348/news.rss?menuNo=201109",
     "https://www.bok.or.kr/portal/bbs/B0000348/list.do?menuNo=201109"),
    ("한국은행 · 주력산업", "https://www.bok.or.kr/portal/bbs/B0000357/news.rss?menuNo=201127",
     "https://www.bok.or.kr/portal/bbs/B0000357/list.do?menuNo=201127"),
    ("미 연준 · 통화정책", "https://www.federalreserve.gov/feeds/press_monetary.xml",
     "https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm"),
)


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def rss_items(raw, host):
    if len(raw) > MAX_FEED_BYTES or b"<!DOCTYPE" in raw.upper():
        raise ValueError("Unexpected RSS document")
    entries = {}
    for item in ElementTree.fromstring(raw).findall("./channel/item"):
        title = " ".join(item.findtext("title", "").split())
        link = item.findtext("link", "").strip()
        try:
            url = urlsplit(link)
            date = parsedate_to_datetime(item.findtext("pubDate", ""))
        except (TypeError, ValueError, OverflowError):
            continue
        if (not title or not date.tzinfo or url.scheme != "https" or url.netloc != host
                or url.username or url.password or len(link) > 1500):
            continue
        entries[link] = {"title": title[:220], "url": link, "published": date.isoformat()}
    return sorted(entries.values(), key=lambda row: datetime.fromisoformat(row["published"]), reverse=True)[:5]


def load_feed(feed, previous, now):
    label, url, home = feed
    try:
        request = Request(url, headers={"User-Agent": "MICU Market Report Reader/1.0", "Accept": "application/rss+xml, application/xml"})
        with build_opener(NoRedirect()).open(request, timeout=8) as response:
            items = rss_items(response.read(MAX_FEED_BYTES + 1), urlsplit(url).netloc)
        if not items:
            raise ValueError("No valid report metadata")
        return {"label": label, "home": home, "items": items, "updated": now, "status": "ok"}
    except (OSError, ValueError, ElementTree.ParseError):
        cached = previous.get(label, {})
        return {"label": label, "home": home, "items": cached.get("items", []),
                "updated": cached.get("updated"), "status": "cached" if cached.get("items") else "unavailable"}


def refresh():
    # The existing demo already serves data.js, so teams keep the same invitation URL.
    base, _, old = DATA.read_text(encoding="utf-8").partition(MARKER)
    try:
        previous = {feed["label"]: feed for feed in json.loads(old.strip().removesuffix(";"))["feeds"]}
    except (ValueError, KeyError, TypeError):
        previous = {}
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with ThreadPoolExecutor(max_workers=len(FEEDS)) as executor:
        feeds = list(executor.map(lambda feed: load_feed(feed, previous, now), FEEDS))
    payload = {"checked": now, "feeds": feeds}
    with NamedTemporaryFile(mode="w", encoding="utf-8", dir=DATA.parent, delete=False) as file:
        temp = Path(file.name)
        file.write(base.rstrip() + MARKER + json.dumps(payload, ensure_ascii=True) + ";\n")
    try:
        os.replace(temp, DATA)
    finally:
        temp.unlink(missing_ok=True)
    return [(group["label"], group["status"], len(group["items"])) for group in feeds]


def poll_reports(stop, active=lambda: True):
    while active() and not stop.is_set():
        try:
            print("Market reports:", refresh(), flush=True)
        except OSError as error:
            print("Could not save market reports:", error.__class__.__name__, flush=True)
        for _ in range(REFRESH_SECONDS // 5):
            if stop.wait(5) or not active():
                return


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--demo-lock", type=Path)
    args = parser.parse_args()
    if args.demo_lock:
        lock_value = args.demo_lock.read_text(encoding="utf-8")

        def same_demo():
            return args.demo_lock.is_file() and args.demo_lock.read_text(encoding="utf-8") == lock_value

        poll_reports(Event(), same_demo)
    else:
        print("Market reports:", refresh(), flush=True)
