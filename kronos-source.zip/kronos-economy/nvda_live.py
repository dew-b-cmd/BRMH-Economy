"""Nasdaq daily bars and the US regular-session calendar for NVDA."""

import csv
from datetime import datetime, timedelta
from functools import lru_cache
from io import StringIO
import json
from math import isfinite
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from research_data import PRICE_FIELDS


NASDAQ_HISTORY = "https://api.nasdaq.com/api/quote/NVDA/historical"
NASDAQ_SOURCE = "https://www.nasdaq.com/market-activity/stocks/nvda/historical"

# Nasdaq's 2026 calendar and the published US equity market dates for 2027–2028.
HOLIDAYS = {
    2026: frozenset("01-01 01-19 02-16 04-03 05-25 06-19 07-03 09-07 11-26 12-25".split()),
    2027: frozenset("01-01 01-18 02-15 03-26 05-31 06-18 07-05 09-06 11-25 12-24".split()),
    2028: frozenset("01-17 02-21 04-14 05-29 06-19 07-04 09-04 11-23 12-25".split()),
}
EARLY_CLOSES = {"2026-11-27", "2026-12-24", "2027-11-26", "2028-07-03", "2028-11-24"}


@lru_cache(maxsize=1)
def new_york_zone():
    name = "America/New_York"
    try:
        return ZoneInfo(name)
    except ZoneInfoNotFoundError:
        # A bare Windows Python can use the tzdata already installed with the model.
        zone_file = Path(__file__).resolve().parent / ".venv/Lib/site-packages/tzdata/zoneinfo" / name
        try:
            with zone_file.open("rb") as zone:
                return ZoneInfo.from_file(zone, key=name)
        except FileNotFoundError:
            raise ValueError("미국 거래일 계산에 Python의 tzdata가 필요합니다.") from None


def is_trading_day(day):
    if day.year not in HOLIDAYS:
        raise ValueError("미국 주식시장 휴장일 일정표를 업데이트해야 합니다.")
    return day.weekday() < 5 and day.strftime("%m-%d") not in HOLIDAYS[day.year]


def trading_window(now, horizon):
    eastern = now.astimezone(new_york_zone())
    day = eastern.date()
    close_hour = 13 if day.isoformat() in EARLY_CLOSES else 16
    if eastern.hour < close_hour:
        day -= timedelta(days=1)
    while not is_trading_day(day):
        day -= timedelta(days=1)

    completed = day
    future = []
    while len(future) < horizon:
        day += timedelta(days=1)
        if is_trading_day(day):
            future.append(day.isoformat())
    return completed, tuple(future)


def parse_nasdaq_bars(raw, through):
    payload = json.loads(raw)["data"]
    if payload["symbol"] != "NVDA":
        raise ValueError("Unexpected Nasdaq symbol")
    bars = {}
    for row in payload["tradesTable"]["rows"]:
        day = datetime.strptime(row["date"], "%m/%d/%Y").date()
        if day > through:
            continue
        opening, high, low, close, volume = values = tuple(
            float(row[field].replace("$", "").replace(",", "")) for field in PRICE_FIELDS[1:]
        )
        if (day in bars or day.weekday() >= 5 or not all(map(isfinite, values))
                or not 0 < low <= min(opening, close) <= max(opening, close) <= high or volume < 0):
            raise ValueError("Invalid Nasdaq daily bar")
        bars[day] = values
    if len(bars) < 2:
        raise ValueError("Too few Nasdaq daily bars")
    return tuple(sorted(bars.items()))


def model_csv(bars):
    stream = StringIO(newline="")
    writer = csv.writer(stream)
    writer.writerow(PRICE_FIELDS)
    writer.writerows((day.isoformat(), *values) for day, values in bars)
    return stream.getvalue()
