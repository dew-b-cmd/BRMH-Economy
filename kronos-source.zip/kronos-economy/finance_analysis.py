"""Select and compare annual SEC XBRL facts from one filing."""

from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from urllib.parse import urlsplit

FASTINO_MODEL = "fastino/Fastino-Nemotron-3.5-Super-VL-Finance"
METRICS = (
    ("revenue", "매출", ("RevenueFromContractWithCustomerExcludingAssessedTax",
                         "Revenues", "SalesRevenueNet",
                         "RevenueFromContractWithCustomerIncludingAssessedTax")),
    ("net_income", "순이익", ("NetIncomeLoss",)),
)


def annual_facts(rows, filing):
    """Exclude quarterly and year-to-date periods and facts from other filings."""
    periods = {}
    if not isinstance(rows, list):
        return periods
    for row in rows:
        if (not isinstance(row, dict) or row.get("accn") != filing["accession"]
                or type(row.get("val")) is not int):
            continue
        try:
            start = date.fromisoformat(row["start"])
            end = date.fromisoformat(row["end"])
        except (KeyError, ValueError, TypeError):
            continue
        if 350 <= (end - start).days + 1 <= 380:
            periods.setdefault(end, set()).add(row["val"])
    return {end: values.pop() for end, values in periods.items() if len(values) == 1}


def annual_metrics(company_facts, filing):
    """Use the comparison column from the same 10-K and the same USD tag."""
    facts = company_facts.get("facts", {})
    gaap = facts.get("us-gaap", {}) if isinstance(facts, dict) else {}
    if not isinstance(gaap, dict):
        return []
    period = date.fromisoformat(filing["period"])
    metrics = []
    for metric_id, label, tags in METRICS:
        candidates = []
        for tag in tags:
            fact = gaap.get(tag)
            units = fact.get("units") if isinstance(fact, dict) else None
            rows = units.get("USD") if isinstance(units, dict) else None
            years = annual_facts(rows, filing)
            if period not in years:
                continue
            previous = max((end for end in years if 350 <= (period - end).days <= 380), default=None)
            current, prior = years[period], years.get(previous)
            change = None
            if prior is not None and prior > 0:
                change = float(((Decimal(current) / prior - 1) * 100).quantize(
                    Decimal("0.01"), rounding=ROUND_HALF_UP))
            candidates.append({
                "id": metric_id, "label": label, "tag": tag, "unit": "USD",
                "period": period.isoformat(), "value": current,
                "prior_period": previous.isoformat() if previous else None, "prior_value": prior,
                "change_pct": change,
            })
        if candidates:
            metrics.append(next((row for row in candidates if row["prior_period"]), candidates[0]))
    return metrics


def model_url(base):
    url = urlsplit(base.rstrip("/"))
    loopback = url.hostname in ("localhost", "127.0.0.1", "::1")
    if (not url.hostname or url.username is not None or url.password is not None
            or url.query or url.fragment or not (url.scheme == "https" or url.scheme == "http" and loopback)):
        raise ValueError("Use HTTPS or a local HTTP endpoint.")
    return base.rstrip("/") + "/chat/completions"
