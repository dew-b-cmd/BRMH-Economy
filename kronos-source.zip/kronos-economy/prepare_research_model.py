"""Download the pinned Kronos CPU experiment weights into the project cache."""

from pathlib import Path
from time import sleep

from huggingface_hub import hf_hub_download
from requests.exceptions import ChunkedEncodingError, ConnectionError, Timeout


MODELS = (
    ("NeoQuasar/Kronos-Tokenizer-base", "0e0117387f39004a9016484a186a908917e22426", "tokenizer"),
    ("NeoQuasar/Kronos-small", "901c26c1332695a2a8f243eb2f37243a37bea320", "predictor"),
)


def main():
    root = Path(__file__).resolve().parent
    destination = (root / ".research-cache" / "models").resolve()
    if not destination.is_relative_to(root):
        raise ValueError("모델 폴더가 프로젝트 밖에 있습니다.")
    for repo, revision, folder in MODELS:
        for filename in ("config.json", "model.safetensors"):
            for attempt in range(3):
                try:
                    hf_hub_download(repo, filename, revision=revision, local_dir=destination / folder, token=False)
                    break
                except (ChunkedEncodingError, ConnectionError, Timeout):
                    if attempt == 2:
                        raise
                    print(f"{repo}: retrying interrupted download", flush=True)
                    sleep(2)
        print(f"{repo} ready", flush=True)


if __name__ == "__main__":
    main()
